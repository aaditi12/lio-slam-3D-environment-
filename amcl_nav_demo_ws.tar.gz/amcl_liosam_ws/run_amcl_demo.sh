#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════
#  run_amcl_demo.sh
#  ─────────────────
#  Two-phase demo:
#    Phase 1 (MAP BUILD)   — Gazebo + slam_toolbox + teleop → save map
#    Phase 2 (LOCALIZE)    — Gazebo + Nav2 AMCL on saved map + RViz
#
#  Prerequisites (install once):
#    sudo apt install tmux \
#         ros-humble-nav2-amcl \
#         ros-humble-nav2-map-server \
#         ros-humble-nav2-lifecycle-manager \
#         ros-humble-nav2-bringup \
#         ros-humble-slam-toolbox \
#         ros-humble-teleop-twist-keyboard \
#         ros-humble-gazebo-ros-pkgs \
#         ros-humble-xacro
#
#  Usage:
#    cd ~/Downloads/amcl_nav_demo_ws
#    colcon build --packages-select amcl_nav_demo --symlink-install
#    source install/setup.bash
#
#    # Phase 1 — build a map:
#    bash run_amcl_demo.sh map
#    # Drive the robot with teleop (window 3), then save with:
#    #   ros2 launch amcl_nav_demo map_saver.launch.py
#
#    # Phase 2 — localize on the saved map:
#    bash run_amcl_demo.sh localize
# ═══════════════════════════════════════════════════════════════════
set -e

MODE="${1:-localize}"
SESSION="amcl_demo"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WS_DIR="${ROS2_WS:-$SCRIPT_DIR}"
SETUP="source $WS_DIR/install/setup.bash"
DELAY_GAZEBO=7

GREEN="\033[1;32m"; YELLOW="\033[1;33m"; CYAN="\033[1;36m"; NC="\033[0m"
info() { echo -e "${CYAN}[amcl_demo]${NC} $*"; }
ok()   { echo -e "${GREEN}[  OK  ]${NC} $*"; }

command -v tmux >/dev/null || { echo "❌  tmux not found"; exit 1; }
command -v ros2  >/dev/null || { echo "❌  ROS2 not sourced"; exit 1; }
[ -f "$WS_DIR/install/setup.bash" ] || {
  echo "❌  Not built. Run: colcon build --packages-select amcl_nav_demo --symlink-install"
  exit 1
}

killall -9 gzserver gzclient 2>/dev/null && info "Killed stale Gazebo" || true
tmux kill-session -t "$SESSION" 2>/dev/null || true
sleep 1

# ── Shared window 0: Gazebo ─────────────────────────────────────
info "Starting Gazebo …"
tmux new-session -d -s "$SESSION" -x 220 -y 50
tmux rename-window -t "$SESSION:0" "Gazebo"
tmux send-keys -t "$SESSION:0" \
  "export LIBGL_ALWAYS_SOFTWARE=1 && $SETUP && \
   ros2 launch amcl_nav_demo gazebo_spawn.launch.py" Enter

if [ "$MODE" = "map" ]; then
  # ── Phase 1: slam_toolbox mapping ──────────────────────────────
  info "Phase 1: MAP BUILD with slam_toolbox"

  tmux new-window -t "$SESSION" -n "SLAM"
  tmux send-keys -t "$SESSION:1" \
    "sleep $DELAY_GAZEBO && $SETUP && \
     echo '🗺️  Starting slam_toolbox online async …' && \
     ros2 launch slam_toolbox online_async_launch.py \
       use_sim_time:=true slam_params_file:=/opt/ros/humble/share/slam_toolbox/config/mapper_params_online_async.yaml" Enter

  tmux new-window -t "$SESSION" -n "RViz"
  tmux send-keys -t "$SESSION:2" \
    "sleep $((DELAY_GAZEBO+4)) && export LIBGL_ALWAYS_SOFTWARE=1 && \
     $SETUP && ros2 launch amcl_nav_demo rviz.launch.py" Enter

  tmux new-window -t "$SESSION" -n "Teleop"
  tmux send-keys -t "$SESSION:3" \
    "sleep $((DELAY_GAZEBO+4)) && $SETUP && \
     echo '🕹️  Drive to build map!  i=fwd  ,=back  j=left  l=right  k=stop' && \
     ros2 run teleop_twist_keyboard teleop_twist_keyboard \
       --ros-args --remap cmd_vel:=/cmd_vel" Enter

  tmux new-window -t "$SESSION" -n "SaveMap"
  tmux send-keys -t "$SESSION:4" \
    "sleep $((DELAY_GAZEBO+4)) && $SETUP && \
     echo '💾  When map looks good in RViz, run:' && \
     echo '    ros2 launch amcl_nav_demo map_saver.launch.py'" Enter

  ok "Map-build session started"
  echo ""
  echo -e "${YELLOW}Windows:${NC} 0=Gazebo  1=SLAM  2=RViz  3=Teleop  4=SaveMap"
  echo ""
  echo -e "${YELLOW}When map looks complete in RViz:${NC}"
  echo "  Switch to window 4 and run the map_saver command shown there."
  echo "  Then restart with:  bash run_amcl_demo.sh localize"

else
  # ── Phase 2: AMCL localization ─────────────────────────────────
  MAP_FILE="$WS_DIR/install/amcl_nav_demo/share/amcl_nav_demo/maps/my_map.yaml"
  if [ ! -f "$MAP_FILE" ]; then
    echo -e "${YELLOW}⚠  Map not found at $MAP_FILE${NC}"
    echo "   Run Phase 1 first:  bash run_amcl_demo.sh map"
    echo "   Then rebuild and re-source, or pass map:= arg manually."
  fi

  info "Phase 2: LOCALIZATION with Nav2 AMCL"

  tmux new-window -t "$SESSION" -n "AMCL"
  tmux send-keys -t "$SESSION:1" \
    "sleep $DELAY_GAZEBO && $SETUP && \
     echo '📍 Starting Nav2 AMCL localization …' && \
     ros2 launch amcl_nav_demo amcl.launch.py" Enter

  tmux new-window -t "$SESSION" -n "RViz"
  tmux send-keys -t "$SESSION:2" \
    "sleep $((DELAY_GAZEBO+5)) && export LIBGL_ALWAYS_SOFTWARE=1 && \
     $SETUP && ros2 launch amcl_nav_demo rviz.launch.py" Enter

  tmux new-window -t "$SESSION" -n "Teleop"
  tmux send-keys -t "$SESSION:3" \
    "sleep $((DELAY_GAZEBO+5)) && $SETUP && \
     echo '🕹️  Drive the robot — watch particle cloud converge!' && \
     echo '    i=fwd  ,=back  j=left  l=right  k=stop  q/z=speed' && \
     ros2 run teleop_twist_keyboard teleop_twist_keyboard \
       --ros-args --remap cmd_vel:=/cmd_vel" Enter

  tmux new-window -t "$SESSION" -n "MapSub"
  tmux send-keys -t "$SESSION:4" \
    "sleep $((DELAY_GAZEBO+5)) && $SETUP && \
     ros2 run amcl_nav_demo map_subscriber.py" Enter

  ok "AMCL localization session started"
  echo ""
  echo -e "${YELLOW}Windows:${NC} 0=Gazebo  1=AMCL  2=RViz  3=Teleop  4=MapSub"
  echo ""
  echo -e "${YELLOW}In RViz:${NC}"
  echo "  Add display: /map (Map), /scan (LaserScan), /amcl_pose, /particlecloud"
  echo "  Use '2D Pose Estimate' tool if particle cloud is off."
fi

echo ""
echo -e "${YELLOW}Attach:${NC}  tmux attach -t $SESSION"
echo -e "${YELLOW}Kill:${NC}    tmux kill-session -t $SESSION && killall -9 gzserver gzclient"
echo ""

tmux select-window -t "$SESSION:3"
tmux attach -t "$SESSION"
