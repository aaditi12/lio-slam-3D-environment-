# amcl_nav_demo

Gazebo Classic 11 + ROS 2 Humble navigation demo featuring:

| Algorithm | Type | ROS 2 Package | Status |
|-----------|------|--------------|--------|
| **Nav2 AMCL** | Monte Carlo Localization (2D, localization-only) | `nav2_amcl` | ✅ apt Humble |
| **LIO-SAM** | LiDAR-Inertial Odometry SLAM (3D) | community port | ℹ️ see below |

> **Removed**: Cartographer and RTAB-Map dependencies are fully stripped.

---

## Robot

Differential-drive robot with:
- 2D LiDAR (360°, `/scan`)
- Simulated Intel RealSense D435 (RGB-D, `/camera/...`)

## Quick Start

```bash
# Install deps
sudo apt install tmux \
  ros-humble-nav2-amcl \
  ros-humble-nav2-map-server \
  ros-humble-nav2-lifecycle-manager \
  ros-humble-nav2-bringup \
  ros-humble-slam-toolbox \
  ros-humble-teleop-twist-keyboard \
  ros-humble-gazebo-ros-pkgs \
  ros-humble-xacro

# Build
cd ~/Downloads/amcl_nav_demo_ws
colcon build --packages-select amcl_nav_demo --symlink-install
source install/setup.bash

# Phase 1 — drive around to build a map
bash run_amcl_demo.sh map
# In window 4, save the map:
#   ros2 launch amcl_nav_demo map_saver.launch.py
# Rebuild so the map is installed:
#   colcon build --packages-select amcl_nav_demo --symlink-install

# Phase 2 — localize on the saved map
bash run_amcl_demo.sh localize
```

---

## Launch Files

| File | Purpose |
|------|---------|
| `gazebo_spawn.launch.py` | Gazebo + robot URDF spawn |
| `amcl.launch.py` | Nav2 AMCL localization (map_server + amcl + lifecycle_manager) |
| `map_saver.launch.py` | Save current `/map` to `maps/my_map.yaml` |
| `lio_sam_info.launch.py` | LIO-SAM install/run documentation stub |
| `rviz.launch.py` | RViz2 viewer |

---

## Nav2 AMCL

AMCL is a **localization-only** algorithm — it does NOT build maps.

```
Workflow
  slam_toolbox (map build) → map_saver → my_map.yaml/pgm
                                              ↓
                                    nav2_amcl (load map)
                                    nav2_map_server
                                    nav2_lifecycle_manager
                                              ↓
                                    /map → /amcl_pose + TF map→odom
```

Key parameters (`config/amcl_params.yaml`):

| Parameter | Value | Meaning |
|-----------|-------|---------|
| `min_particles` | 500 | Minimum particle filter size |
| `max_particles` | 2000 | Maximum |
| `robot_model_type` | `DifferentialMotionModel` | Diff-drive |
| `laser_model_type` | `likelihood_field` | Scan matching |
| `update_min_d` | 0.25 m | Distance before filter update |
| `update_min_a` | 0.2 rad | Angle before filter update |

To set a manual initial pose (if AMCL diverges):
```bash
# Via RViz: click "2D Pose Estimate" tool, click on map at robot's real position
# Or via CLI:
ros2 topic pub /initialpose geometry_msgs/msg/PoseWithCovarianceStamped \
  "{ header: {frame_id: map}, pose: { pose: { position: {x: -1.8, y: 3.0} } } }" --once
```

---

## LIO-SAM

LIO-SAM is a **3D LiDAR + IMU SLAM** algorithm.

**This robot's 2D LiDAR + no IMU is insufficient.**
To use LIO-SAM you need to:
1. Add a 3D LiDAR (Velodyne VLP-16 or Ouster OS1) Gazebo plugin to the URDF.
2. Add an IMU Gazebo plugin to the URDF.
3. Clone and build the community ROS2 port:

```bash
# GTSAM
sudo add-apt-repository ppa:borglab/gtsam-release-4.1
sudo apt update && sudo apt install libgtsam-dev libgtsam-unstable-dev

# LIO-SAM ROS2 port
mkdir -p ~/lio_sam_ws/src && cd ~/lio_sam_ws/src
git clone https://github.com/TixiaoShan/LIO-SAM.git
cd ~/lio_sam_ws
colcon build --symlink-install --cmake-args -DCMAKE_BUILD_TYPE=Release

# Run
source ~/lio_sam_ws/install/setup.bash
ros2 launch lio_sam run.launch.py
```

See `launch/lio_sam_info.launch.py` for the full reference.

---

## Algorithm Comparison

| Algorithm | Sensor | Dimensionality | Real-time | Loop Closure | Mode |
|-----------|--------|---------------|-----------|-------------|------|
| slam_toolbox | 2D LiDAR | 2D | ✅ | ✅ | Mapping |
| LIO-SAM | LiDAR + IMU | 3D | ✅ | ✅ | Mapping |
| Nav2 AMCL | 2D LiDAR | 2D | ✅ | ❌ | Localization only |
