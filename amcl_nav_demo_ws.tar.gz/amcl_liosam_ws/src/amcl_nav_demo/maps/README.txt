Place generated map files here:
  my_map.yaml
  my_map.pgm

Generate them while slam_toolbox is running:
  ros2 launch amcl_nav_demo map_saver.launch.py
