"""
rviz.launch.py
──────────────
Launches RViz2 with the SLAM configuration.
Run this in a THIRD terminal.
"""

import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():

    pkg      = get_package_share_directory("amcl_nav_demo")
    rviz_cfg = os.path.join(pkg, "config", "amcl_rviz.rviz")

    rviz = Node(
        package="rviz2",
        executable="rviz2",
        name="rviz2",
        output="screen",
        arguments=["-d", rviz_cfg],
        parameters=[{"use_sim_time": True}],
    )

    return LaunchDescription([rviz])
