"""
amcl.launch.py
──────────────
Nav2 AMCL localization-only launch.

Type   : Monte Carlo Localization (particle filter)
Mode   : Localization ONLY — does NOT build a map.
         Requires a pre-built map (.yaml + .pgm) produced by slam_toolbox
         or map_saver (see map_saver.launch.py).
Sensor : 2D LiDAR → /scan
TF     : map → odom (AMCL); odom → base_footprint (Gazebo diff-drive plugin)

Nodes launched:
  nav2_map_server  — serves the static .yaml/.pgm map on /map
  nav2_amcl        — particle-filter localizer, publishes map→odom TF
  nav2_lifecycle_manager — starts both nodes through their lifecycle

Usage
─────
  # 1. Build a map first (drive the robot around):
  ros2 launch amcl_nav_demo map_saver.launch.py      # saves maps/my_map.yaml

  # 2. Then start localization:
  ros2 launch amcl_nav_demo amcl.launch.py \\
      map:=$(ros2 pkg prefix amcl_nav_demo)/share/amcl_nav_demo/maps/my_map.yaml

  # 3. In RViz set a 2D Pose Estimate if the initial_pose in amcl_params.yaml
  #    does not match the robot's current position.
"""

import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():

    pkg = get_package_share_directory("amcl_nav_demo")

    default_map = os.path.join(pkg, "maps", "my_map.yaml")
    params_file  = os.path.join(pkg, "config", "amcl_params.yaml")

    declare_map = DeclareLaunchArgument(
        "map",
        default_value=default_map,
        description="Full path to the map YAML file",
    )
    declare_use_sim_time = DeclareLaunchArgument(
        "use_sim_time",
        default_value="true",
        description="Use Gazebo simulation clock",
    )

    map_server = Node(
        package="nav2_map_server",
        executable="map_server",
        name="map_server",
        output="screen",
        parameters=[{
            "use_sim_time": LaunchConfiguration("use_sim_time"),
            "yaml_filename": LaunchConfiguration("map"),
        }],
    )

    amcl = Node(
        package="nav2_amcl",
        executable="amcl",
        name="amcl",
        output="screen",
        parameters=[
            params_file,
            {"use_sim_time": LaunchConfiguration("use_sim_time")},
        ],
        remappings=[("scan", "/scan")],
    )

    # lifecycle_manager activates map_server and amcl in order
    lifecycle_manager = Node(
        package="nav2_lifecycle_manager",
        executable="lifecycle_manager",
        name="lifecycle_manager_localization",
        output="screen",
        parameters=[{
            "use_sim_time": LaunchConfiguration("use_sim_time"),
            "autostart": True,
            "node_names": ["map_server", "amcl"],
        }],
    )

    return LaunchDescription([
        declare_map,
        declare_use_sim_time,
        map_server,
        amcl,
        lifecycle_manager,
    ])
