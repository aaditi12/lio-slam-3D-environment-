"""
lio_sam_info.launch.py
──────────────────────
LIO-SAM  —  LiDAR-Inertial Odometry SLAM
Type   : 3D SLAM (LiDAR + IMU tightly-coupled)
Status : Community-maintained ROS2 port (not an official Humble apt package)

Algorithm overview
──────────────────
  • Factor-graph back-end (GTSAM)
  • Front-end: point cloud feature extraction (edges + planes)
  • IMU pre-integration between LiDAR scans for fast odometry
  • Loop closure: Euclidean distance heuristics + ICP refinement
  • GPS fusion: optional (NavSatFix → UTM)
  • Output: 3D point cloud map + /odometry/imu path

Hardware requirements
─────────────────────
  Sensor        | Topic (default)          | Message type
  ──────────────┼──────────────────────────┼──────────────────────────
  3D LiDAR      | /points_raw              | sensor_msgs/PointCloud2
  IMU (9-DoF)   | /imu_raw                 | sensor_msgs/Imu
  GPS (optional)| /gps/fix                 | sensor_msgs/NavSatFix

  Note: This demo uses a 2D LiDAR + no IMU → LIO-SAM is NOT directly
  runnable without hardware changes.  See urdf/diff_robot.urdf.xacro and
  add a 3D LiDAR (Velodyne VLP-16 / Ouster OS1) and IMU Gazebo plugins.

Installation (one-time)
───────────────────────
  # GTSAM (required)
  sudo add-apt-repository ppa:borglab/gtsam-release-4.1
  sudo apt update && sudo apt install libgtsam-dev libgtsam-unstable-dev

  # Clone & build the ROS2 port
  mkdir -p ~/lio_sam_ws/src && cd ~/lio_sam_ws/src
  git clone https://github.com/TixiaoShan/LIO-SAM.git
  cd ~/lio_sam_ws
  colcon build --symlink-install --cmake-args -DCMAKE_BUILD_TYPE=Release

Running (after adding 3D LiDAR + IMU to the robot)
───────────────────────────────────────────────────
  # Terminal 1: LIO-SAM
  source ~/lio_sam_ws/install/setup.bash
  ros2 launch lio_sam run.launch.py

  # Terminal 2: RViz (LIO-SAM ships its own config)
  rviz2 -d ~/lio_sam_ws/src/LIO-SAM/config/rviz2.rviz

  # Terminal 3: Bag or live sensor
  ros2 bag play your_lidar_imu_bag.bag

Saving the 3D map
─────────────────
  ros2 service call /lio_sam/save_map lio_sam/srv/SaveMap "{}"
  # Saved to ~/Downloads/amcl_nav_demo_ws/LIO-SAM/maps/

Reference
─────────
  T. Shan, B. Englot, D. Meyers, W. Wang, C. Ratti, D. Rus,
  "LIO-SAM: Tightly-coupled Lidar Inertial Odometry via Smoothing and
  Mapping," IROS 2020.  https://github.com/TixiaoShan/LIO-SAM
"""

# This file is intentionally documentation-only.
# No nodes are launched — LIO-SAM requires the community ROS2 port
# to be separately cloned, built, and configured for your sensor setup.

from launch import LaunchDescription
from launch.actions import LogInfo


def generate_launch_description():
    return LaunchDescription([
        LogInfo(msg=(
            "\n"
            "╔══════════════════════════════════════════════════════════════╗\n"
            "║  LIO-SAM is a community-maintained ROS2 port.               ║\n"
            "║  This launch file is an informational stub.                 ║\n"
            "║  See the docstring at the top of this file for install and  ║\n"
            "║  run instructions, or read README.md.                       ║\n"
            "╚══════════════════════════════════════════════════════════════╝\n"
        )),
    ])
