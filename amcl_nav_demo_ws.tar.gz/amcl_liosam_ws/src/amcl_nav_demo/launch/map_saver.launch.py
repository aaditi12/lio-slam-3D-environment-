"""
map_saver.launch.py
───────────────────
Saves the current OccupancyGrid on /map to disk so AMCL can load it.

Run this WHILE slam_toolbox (or any other SLAM node) is active and the
map looks good in RViz.  A two-file artefact is produced:
  maps/my_map.pgm   — greyscale image (255=free, 0=occupied, 128=unknown)
  maps/my_map.yaml  — metadata (resolution, origin, thresholds)

Usage
─────
  ros2 launch amcl_nav_demo map_saver.launch.py
  # or override the output path:
  ros2 launch amcl_nav_demo map_saver.launch.py map_name:=warehouse

Note: map_saver_cli exits immediately after saving — that is expected.
The node is not long-running.
"""

import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, ExecuteProcess
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution


def generate_launch_description():

    pkg = get_package_share_directory("amcl_nav_demo")
    maps_dir = os.path.join(pkg, "maps")

    declare_map_name = DeclareLaunchArgument(
        "map_name",
        default_value="my_map",
        description="Base filename (no extension) for the saved map",
    )

    save_map = ExecuteProcess(
        cmd=[
            "ros2", "run", "nav2_map_server", "map_saver_cli",
            "-f", PathJoinSubstitution([maps_dir, LaunchConfiguration("map_name")]),
            "--ros-args", "-p", "use_sim_time:=true",
        ],
        output="screen",
    )

    return LaunchDescription([
        declare_map_name,
        save_map,
    ])
